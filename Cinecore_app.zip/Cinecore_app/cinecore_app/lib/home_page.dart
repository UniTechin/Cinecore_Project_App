import 'package:flutter/material.dart';
import 'movie_detail_page.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16.0),
        children: <Widget>[
          _buildMovieItem(
            context,
            'Inception',
            'https://image.tmdb.org/t/p/w600_and_h900_bestv2/oYuLEt3zVCKq57qu2F8dT7NIa6f.jpg',
            'Inception is a mind-bending action thriller.',
            2010,
            'Action',
            'A thief who enters the dreams of others.',
            8.8,
          ),
          _buildMovieItem(
            context,
            'The Shawshank Redemption',
            'https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg',
            'The Shawshank Redemption is a prison drama film.',
            1994,
            'Drama',
            'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.',
            9.3,
          ),
          _buildMovieItem(
            context,
            'The Dark Knight',
            'https://image.tmdb.org/t/p/w500/1hRoyzDtpgMU7Dz4JF22RANzQO7.jpg',
            'The Dark Knight is a superhero film based on the DC Comics character Batman.',
            2008,
            'Action',
            'When the menace known as The Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.',
            9.0,
          ),
          _buildMovieItem(
            context,
            'The Marvels',
            'https://image.tmdb.org/t/p/w600_and_h900_bestv2/9GBhzXMFjgcZ3FdR9w3bUMMTps5.jpg',
            'The Marvels is an upcoming American superhero film.',
            2022,
            'Action, Adventure, Fantasy',
            'Follows the story of Carol Danvers as she becomes one of the universe\'s most powerful heroes when Earth is caught in the middle of a galactic war between two alien races.',
            8.5,
          ),
          _buildMovieItem(
            context,
            'No Way Up',
            'https://image.tmdb.org/t/p/w600_and_h900_bestv2/9YTdswepVeqnZYo2Mkdn3mKNraF.jpg',
            'No Way Up is an action thriller film.',
            2023,
            'Action, Thriller',
            'An ex-soldier finds himself on a warpath, as he tries to uncover the truth behind a deadly conspiracy.',
            7.9,
          ),
          _buildMovieItem(
            context,
            'Aquaman and the Lost Kingdom',
            'https://image.tmdb.org/t/p/w600_and_h900_bestv2/7lTnXOy0iNtBAdRP3TZvaKJ77F6.jpg',
            'Aquaman and the Lost Kingdom is an upcoming superhero film.',
            2023,
            'Action, Adventure, Fantasy',
            'The sequel to Aquaman (2018), and it is the 11th film in the DC Extended Universe (DCEU).',
            8.1,
          ),
          // Add more movie items here
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton(
            onPressed: () {
              Navigator.pushNamed(context, '/watchlist');
            },
            child: Icon(Icons.playlist_add),
          ),
          SizedBox(height: 16),
          FloatingActionButton(
            onPressed: () {
              Navigator.pushNamed(context, '/moviereview');
            },
            child: Icon(Icons.rate_review),
          ),
        ],
      ),
    );
  }

  Widget _buildMovieItem(
    BuildContext context,
    String title,
    String imageUrl,
    String description,
    int releaseYear,
    String genre,
    String synopsis,
    double rating,
  ) {
    return Card(
      elevation: 4.0,
      margin: EdgeInsets.only(bottom: 16.0),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => MovieDetailPage(
                title: title,
                releaseYear: releaseYear,
                genre: genre,
                synopsis: synopsis,
                rating: rating,
                imageUrl: imageUrl,
                description: description,
              ),
            ),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Image.network(
              imageUrl,
              width: double.infinity,
              height: 200.0,
              fit: BoxFit.cover,
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 18.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
