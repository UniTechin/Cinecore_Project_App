import 'package:flutter/material.dart';

class MovieReviewPage extends StatelessWidget {
  final List<String> reviews = [
    'Review 1',
    'Review 2',
    'Review 3',
    // Add more reviews here
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Movie Reviews'),
      ),
      body: ListView.builder(
        itemCount: reviews.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(reviews[index]),
            onTap: () {
              Navigator.pushNamed(context, '/moviereviewdetail');
            },
          );
        },
      ),
    );
  }
}
