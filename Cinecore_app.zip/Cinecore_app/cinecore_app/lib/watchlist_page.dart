import 'package:flutter/material.dart';

class WatchListPage extends StatefulWidget {
  @override
  _WatchListPageState createState() => _WatchListPageState();
}

class _WatchListPageState extends State<WatchListPage> {
  List<String> _watchList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Watch List'),
      ),
      body: ListView.builder(
        itemCount: _watchList.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_watchList[index]),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          String? newMovie = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddMoviePage()),
          );
          if (newMovie != null) {
            setState(() {
              _watchList.add(newMovie);
            });
          }
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class AddMoviePage extends StatelessWidget {
  final TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Movie'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Movie Name',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, _controller.text);
              },
              child: Text('Add to Watch List'),
            ),
          ],
        ),
      ),
    );
  }
}
