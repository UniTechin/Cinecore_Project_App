import 'package:flutter/material.dart';
import 'home_page.dart';
import 'login_page.dart';
import 'signup_page.dart';
import 'watchlist_page.dart';
import 'moviereview_page.dart';
import 'moviereview_detail_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Movie Detail Page Example',
      theme: ThemeData.dark(),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginPage(),
        '/home': (context) => HomePage(),
        '/signup': (context) => SignUpPage(),
        '/watchlist': (context) => WatchListPage(),
        '/moviereview': (context) => MovieReviewPage(),
        '/moviereviewdetail': (context) => MovieReviewDetailPage(),
      },
    );
  }
}
